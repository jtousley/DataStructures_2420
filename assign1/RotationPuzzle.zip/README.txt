Inefficiencies to the algorithm:
Brute force is never as effective as a strategy-based approach. This method tries every approach (which is a lot of moves) - making it an extrememly inefficient algorithm.


Recommendations for improvement:
Develop a method that uses a formula or strategy to solve the puzzle. A monkey could try every possible option (although not in the organized way we did), we need a method that makes intelligent decisions to decide the next move.