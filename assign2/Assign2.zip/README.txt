Binary Search Tree. Implementation for the tree is contained within 
bst.h due to template issues. "node.h" contains the TreeNode class.

Linux:
After unzipping, type "make" without quotes to compile and run.

Questions?
Email me @ j.tousley@live.com
