Jonathan Tousley
A01908436
j.tousley@live.com
Dr. Vicki Allan
Assignment 3 - Priority Queues via AVL Trees

Linux:
A makefile is included, type "make" without quotes to compile and run. I recommend using "make > puzzle.txt" for better review of the output.

Windows:
Should compile, no guarantees. Email me if you have any problems.

General:
Highly recommended you comment out line 108 of Puzzle.cpp and uncomment line 109... BUT, the instructions asked for what the instructions asked.