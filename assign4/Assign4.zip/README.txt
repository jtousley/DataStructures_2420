Jonathan Tousley
A01908436
j.tousley@live.com
Dr. Vicki Allan
Assignment 4 - Hash Tables

Linux:
Makefile is attached, type "make" without quotes to compile and run.
Questions? Email me!


This program lacks the ability to:
	1) View the poem as a whole
	2) Create sentences / use proper punctuation
	3) Move toward a conclusion
These things, among others, cause the program to just write continual words without any meaning.
The poems that orginally had less of a deep meaning and poetic language generally created sentences more intelligible. This makes sense: smaller words can fit into more places.