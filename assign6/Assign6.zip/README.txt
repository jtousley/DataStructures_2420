Jonathan Tousley
A01908436
j.tousley@live.com
Assignment 6 - Class Reunion
11/17/14

Linux:
Makefile included, type "make" without quotes to compile and run.

Windows:
No guarantees.