Jonathan Tousley
A01908436
j.tousley@live.com

Dr. Vicki Allan - Assignment 7 - Graphs

Windows:
I'm about 90% sure this program will NOT compile on windows due to line 54 of Graph.cpp. 
If you really want it to compile on windows, you could probably change it to something like:
int* inDegree = new int[nodeCt];

Linux:
Type "make" without quotes to compile and run. Enjoy!


Questions? Email me!
